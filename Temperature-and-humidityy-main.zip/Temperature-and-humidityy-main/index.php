
<html>
  <head>
    <title>WeatheryApp</title>
    <link rel="stylesheet" href="trial3.css" />
  </head>
  <body>
    <div class="banner">
      <div class="navbar">
        <img src="Weathery.jpeg" class="logo" />
        <ul>
          
          <li><a href="https://google.com" target="_blank">Browser</a></li>
          <li><a href="aboutus.html">More About Us</a></li>
          <li><a href="contact1.php"target="_blank">Contact Us</a></li>
        </ul>
      </div>
      <div class="content">
        <h1>Check The Weather and Humidity</h1>
        <p>
          Here are 2 Options to Check out the Temperature of a certain Region
        </p>
        <div>
           <a href="gap.html">
            <button type="button"><span></span>  Our Location</button>
           </a>
        

           <a href="weatherapi.php" target="_blank">
            <button type="button"><span></span> Any Desired Location</button></a>
        </div>
      </div>
    </div>
    
  </body>
</html>

