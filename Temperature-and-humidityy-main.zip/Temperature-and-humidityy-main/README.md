# Temperature-and-humidityy monitoring System
LANDING PAGE
![landing page - Copy](https://user-images.githubusercontent.com/109501765/200185911-a313f0f6-8e08-447e-81f6-83d74cb7a169.png)
API PAGE
![weathwe api](https://user-images.githubusercontent.com/109501765/200186037-13360d93-137b-45b2-8a0f-80060a15e0af.png)

PAYMENT PAGE


![payment page](https://user-images.githubusercontent.com/109501765/200186104-b6c53356-8b6a-43d0-a43b-e81be1fd2087.png)

TEMPERATURE AND HUMIDITY OUTPUT PAGE 


![data output](https://user-images.githubusercontent.com/109501765/200186181-1a786e49-ad6f-4651-9a2c-2de43d63cb0c.png)

Data Entry Page of Contact Details
![details](https://github.com/manisha765/Temperature-and-humidityy/assets/109501765/3d76accf-fd9d-4066-9a83-84a6bf023af6)

Data Storage of Temperature and humidity in Xampp(Backend)
![data storage of tem and humid](https://github.com/manisha765/Temperature-and-humidityy/assets/109501765/dc030a91-d6c3-4bc0-ac73-ce7f8f67512e)




